package rankingPelis;

import javax.swing.*;


import java.awt.*;
/**
 * Esta clase da una representaci�n en forma de histograma de los votos totales procesados del archivo.
 * La misma extiende de la clase JPanel para poder dibujarse y luego insertarse en el tablero.
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class Histograma extends JPanel {
	/**
	 * El Histograma cuenta con un arreglo en el cual cada posicion corresponde a la cantidad total de veces que se vot�
	 * un n�mero determinado.
	 * por ejemplo: la posici�n 0 corresponde a los cantidad de votos de valor 1 totales.
	 * 
	 * Tambi�n cuenta con una variable boolean que indica si ya se contabilizaron los votos, es decir, si fueron
	 * procesados los archivos.
	 */
	static final long serialVersionUID = 1l;
	
	private int[]arrayVotos = new int[5];
	private boolean arrayInicializado;
	/**
	 * Este constructor se llama para mostrarse en la interfaz del tablero cuando a�n no han sido procesados los archivos.
	 */
	public Histograma() {
		arrayInicializado=false;
	}
	/**
	 * Este constructor se llama cuando finaliza la carga de los datos.
	 * @param v es un arreglo que contiene la cantidad total de cada voto.
	 */
	public Histograma(int[] v) {
		arrayVotos=v;
		arrayInicializado=true;
		
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		crearHistograma(g);
		
				
	}
	/**
	 * Este m�todo dibuja el histograma. En caso de arrayInicializado est� en false, solo dibuja los ejes del gr�fico.
	 * Caso contrario, dibuja efectivamente la estad�stica de los datos seg�n corresponda.
	 * @param gr
	 */
	private void crearHistograma(Graphics gr) {
		this.setBackground(Color.white);
		//Ejes
		gr.setColor(Color.black);
		gr.fillRect(75, 185, 470, 3); // EJE X
		gr.fillRect(135, 20, 3, 190); // EJE Y
		
		//Valores en eje X: cada uno a 76px del otro
		int nro = 1;
		for(int i=135;i<=439;i+=76) {
			
			gr.fillRect(i, 180, 3, 20);
			gr.setFont(new Font("Calibri", Font.BOLD, 18));
			gr.drawString(nro+"", i+38, 205);
			nro++;
		}
		//Valores del eje Y: cada uno a 28px del otro
		nro=40000;
		for(int i=30;i<=160;i+=40) {
			
			gr.fillRect(125, i, 20, 3);
			gr.setFont(new Font("Calibri", Font.BOLD, 18));
			gr.drawString(nro+"", 80, i+8);
			nro-=10000;
			
		}
		if(arrayInicializado) {
			int ejeX = 135;
			gr.setColor(new Color(180,253,254));
			for(int i=0;i<5;i++) {
				if(arrayVotos[i]>0) {
					int cantPixeles = (int) (arrayVotos[i]*0.0035);
					gr.drawRoundRect(ejeX+15, 180-cantPixeles, 50, cantPixeles,10,10);
					gr.fillRect(ejeX+15, 180-cantPixeles, 50, cantPixeles);
					ejeX+=76;
					
				}
			}

		}	
	}
	
	
}
