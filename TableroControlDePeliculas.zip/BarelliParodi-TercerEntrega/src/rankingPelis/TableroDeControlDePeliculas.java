package rankingPelis;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
/**
 * Esta clase representa la ventana principal del tablero la cual extiende de JFrame y es quien se abre al ejecutar
 * la aplicaci�n. 
 * Compacta todos los datos extra�dos de los archivos y los refleja en pantalla de forma amigable para el usuario.
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class TableroDeControlDePeliculas extends JFrame{
	/**
	 * Cuenta con un bot�n para inicializar la carga de datos, una barra de progreso que indica cu�nto falta para finalizar,
	 * tres JTextField para mostrar los datos generales de ambos archivos (cantFilms, cantVotes y cantUsers).
	 * Adem�s cuenta con un selector que permite elegir la cantidad de pel�culas cuya informaci�n va a mostrarse
	 * en una JTable de manera ordenada descendientemente por cantidad de votos. 
	 * Contiene el nombre de la pel�cula, la cantidad de usuarios que votaron por esa pel�cula y la suma total de dichos votos.
	 * 
	 * Por �ltimo, muestra un gr�fico de barras estilo histograma para reflejar la informaci�n de los votos totales realizados.
	 */
	static final long serialVersionUID = 1l;
	
	private JPanel contenedor;
	private JScrollPane scrollPane;
	private JButton cargaDatos;
	private JLabel zonaNorte;
	private JTable tabla;
	private JLabel cantResultados;	
	private JComboBox<String> selector;
	private JProgressBar barraProgreso = new JProgressBar();
	private JTextField cantFilms;
	private JTextField cantVotes;
	private JTextField cantUsers;
	private Histograma histograma;
	private ProcesadorDeArchivos procesador;
	
	/**
	 * El tablero se divide en 3 filas, de una columna cada una. La creaci�n de cada una de ellas es delegada a 
	 * m�todos espec�ficos.
	 * En el constructor se establecen los datos generales como el tama�o, el t�tulo, el color, etc. de la ventana
	 * principal.
	 */
	public TableroDeControlDePeliculas () {
		scrollPane = new JScrollPane();
		contenedor = new JPanel();
		histograma = new Histograma();
		
		
		//Decidimos establecer 3 filas y una columna como Layout principal
		contenedor.setLayout( new GridLayout(3, 1, 5,5));
		contenedor.setBackground(Color.WHITE);
		contenedor.setPreferredSize(new Dimension(650,800));
		
		//Acomodando la ventana
		this.setTitle("Tablero de control de peliculas");
		this.setSize(700,800);
		this.setResizable(true);
		//Primera fila
		
		JPanel primeraFila = crearPrimeraFila();
		
		contenedor.add(primeraFila);
		//Segunda fila
		
		JPanel segundaFila = crearSegundaFila();
		contenedor.add(segundaFila);
		
		//Ultima fila
	    contenedor.add(histograma);
		
		scrollPane.setViewportView(contenedor);
		scrollPane.setBounds(0, 0, 750, 800);
		this.add(scrollPane);
		this.setVisible(true);
	
	}
	
	
	/**
	 * Este m�todo crea la primera fila del Layout general del tablero.
	 * Esta fila cuenta con un BorderLayout para ordenar sus componentes: el t�tulo, la barra de progreso, el bot�n de carga
	 * y los JTextField con la informaci�n general sobre los archivos, los cuales muestran "???" hasta que se realice
	 * la carga de los datos.
	 * @return La primera fila del tablero.
	 */
	private JPanel crearPrimeraFila() {
		JPanel primerFila = new JPanel();
		primerFila.setLayout(new BorderLayout(15,20));
		primerFila.setBackground(Color.WHITE);
	
		
		//Creacion del titulo -- ZONA NORTE DE PRIMER FILA
		zonaNorte= new JLabel("Tablero de control de Pel�culas", SwingConstants.CENTER);
		zonaNorte.setFont(new Font("Arial", Font.BOLD, 25));
		primerFila.setBackground(Color.WHITE);
		primerFila.add(zonaNorte, BorderLayout.NORTH);
		
		//Creacion de JProgressBar -- ZONA ESTE DE LA PRIMER FILA
		barraProgreso.setValue(0);
		barraProgreso.setBorder(null);
		barraProgreso.setPreferredSize(new Dimension(100,30));
		barraProgreso.setBackground(new Color(212,255,218));
		barraProgreso.setForeground(new Color(143,220,154));
		barraProgreso.setMinimum(0);
		barraProgreso.setMaximum(120000);
		barraProgreso.setStringPainted(true);
		
		procesador = new ProcesadorDeArchivos(barraProgreso, this);
		
		cargaDatos = crearBotonDeCarga();
		
		//Jpanel que contiene el bot�n de carga -- ZONA CENTRO DE LA PRIMER FILA
		JPanel panelCentral1 = new JPanel();
		panelCentral1.setOpaque(true);
		panelCentral1.setBackground(Color.WHITE);
		panelCentral1.setLayout(new FlowLayout( FlowLayout.CENTER, 50, 5));
		panelCentral1.add(cargaDatos);
		
		primerFila.add(panelCentral1, BorderLayout.CENTER);
		
		//Creacion de tabla de datos -- ZONA SUR DE LA PRIMER FILA
		JPanel tablaDeDatos = crearTablaDeDatos();
		
		primerFila.add(tablaDeDatos,BorderLayout.SOUTH);
		
		
		JPanel zonaEsteDeFila1 = new JPanel();
		zonaEsteDeFila1.setBackground(Color.white);
		zonaEsteDeFila1.setLayout(new FlowLayout(FlowLayout.CENTER));
		zonaEsteDeFila1.add(barraProgreso);
		
		primerFila.add(zonaEsteDeFila1, BorderLayout.EAST);
		
		return primerFila;
	}
	
	/**
	 * Este m�todo crea la segunda fila del Layout general del tablero.
	 * Contiene el selector de informaci�n a mostrar y la JTable con los datos correspondientes.
	 * @return La segunda fila del tablero.
	 */
	private JPanel crearSegundaFila() {
		JPanel segundaFila = new JPanel();
		segundaFila.setLayout(new BorderLayout());
		
		//Creaci�n de Selector -- ZONA NORTE DE SEGUNDA FILA 
		JPanel zonaNorte2 = new JPanel();
		zonaNorte2.setBackground(Color.WHITE);
		zonaNorte2.setLayout(new FlowLayout(FlowLayout.LEFT));
		cantResultados = new JLabel("Cantidad de resultados a mostrar: ");
		cantResultados.setFont(new Font("Arial", Font.BOLD, 15));
		zonaNorte2.add(cantResultados);
		
		selector = crearSelector();
		
		zonaNorte2.add(selector);
		segundaFila.add(zonaNorte2, BorderLayout.NORTH);
		//Creaci�n de JTable -- ZONA CENTRO DE SEGUNDA FILA
		
		String[] titulos = new String[3];
		titulos[0] = "Nombre de la Pelicula";
		titulos[1] = "# Usuarios";
		titulos[2] = "# Votos";
		DefaultTableModel modeloTabla = new DefaultTableModel(titulos, 0);
		tabla = new JTable(modeloTabla);
		tabla.setEnabled(false);
		tabla.getTableHeader().setReorderingAllowed(false);
		segundaFila.add(new JScrollPane (tabla), BorderLayout.CENTER);
		
		return segundaFila;
	}
	
	
	/**
	 * Este m�todo crea el bot�n que inicia la carga de archivos. Est� separado con objetivo de organizar mejor el c�digo.
	 * @return El bot�n de carga de datos finalizado.
	 */
	private JButton crearBotonDeCarga() {
				
				//Icon del boton
				Image procesarDatos = null;
				URL procesarURL = getClass().getClassLoader().getResource("icons/procesarDatos.png");
				try {
						procesarDatos = ImageIO.read(procesarURL);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				//Personalizaci�n del boton
				cargaDatos = new JButton( new ImageIcon (procesarDatos));
				cargaDatos.setPreferredSize(new Dimension(256,33));
				cargaDatos.addMouseListener(new MouseAdapter() {

		            public void mouseClicked(MouseEvent arg0) {
		            		if (!procesador.getSeCargo()) {
		            		
		            	    procesador.start();
		            		}
		            }
		            
		        });
				return cargaDatos;
	}
	
	/**
	 * Este m�todo crea el selector del Tablero. Est� dividido para mayor organizaci�n del c�digo.
	 * @return El bot�n finalizado.
	 */
	private JComboBox<String> crearSelector(){
		selector = new JComboBox<String>();
		selector.addItem("5");
		selector.addItem("10");
		selector.addItem("20");
		selector.addItem("100");
		selector.addItem("1000");
		selector.addItem("TODOS");
		selector.addActionListener(new ActionListener() {
            //@Override
            public void actionPerformed(ActionEvent e) {
                tabla.removeAll();
                mostrarDatos();
           }
        });
		return selector;
	}
	
	/**
	 * Este m�todo crea los JTextField que muestran la informaci�n total de los archivos: cantidad de usuarios, de votos
	 * y de pel�culas.
	 * @return La tabla con datos de los archivos finalizada.
	 */
	private JPanel crearTablaDeDatos() {
		
		JPanel tablaDatos = new JPanel();
		
		tablaDatos.setLayout(new GridLayout(1,3));
		tablaDatos.setBackground(new Color(183, 212, 232));
		
		//Creacion de cada columna
		JPanel colum1 = new JPanel();
		colum1.setOpaque(false);
		colum1.setBorder(BorderFactory.createLineBorder(Color.black));
		JLabel users = new JLabel("Usuarios");
		
		//Primera columna --  CANTIDAD DE USUARIOS
		cantUsers = new JTextField("???");
		cantUsers.setBorder(null);
		cantUsers.setFont(new Font("Arial", Font.PLAIN, 20));
		cantUsers.setOpaque(false);
		cantUsers.setEditable(false);
		cantUsers.setPreferredSize(new Dimension(233,40));

		cantUsers.setHorizontalAlignment(SwingConstants.CENTER);
		
		users.setFont(new Font("Arial", Font.BOLD, 20));
		colum1.add(cantUsers);
		colum1.add(users);
		
		//Segunda columna -- CANTIDAD DE PELICULAS
		JPanel colum2 = new JPanel();
		colum2.setOpaque(false);
		colum2.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel films = new JLabel("Pel�culas");
		
		cantFilms = new JTextField("???");
		cantFilms.setBorder(null);
		cantFilms.setFont(new Font("Arial", Font.PLAIN, 20));
		cantFilms.setOpaque(false);
		cantFilms.setPreferredSize(new Dimension(233,40));
		cantFilms.setHorizontalAlignment(SwingConstants.CENTER);
		cantFilms.setEditable(false);
		films.setFont(new Font("Arial", Font.BOLD, 20));
		colum2.add(cantFilms);
		colum2.add(films);
		
		//Tercera columna -- CANTIDAD DE VOTOS
		JPanel colum3 = new JPanel();
		colum3.setOpaque(false);
		colum3.setBorder(BorderFactory.createLineBorder(Color.black));
		
		JLabel votes = new JLabel("Cant. de votos");
		
		cantVotes = new JTextField("???");
		cantVotes.setBorder(null);
		cantVotes.setFont(new Font("Arial", Font.PLAIN, 20));
		cantVotes.setOpaque(false);
		cantVotes.setPreferredSize(new Dimension(233,40));
		cantVotes.setHorizontalAlignment(SwingConstants.CENTER);
		cantVotes.setEditable(false);
		votes.setFont(new Font("Arial", Font.BOLD, 20));
		colum3.add(cantVotes);
		colum3.add(votes);
		
		tablaDatos.add(colum1);
		tablaDatos.add(colum2);
		tablaDatos.add(colum3);
		tablaDatos.setPreferredSize(new Dimension(900, 100));
		
		return tablaDatos;
	}
	
	/**
	 * Este m�todo es llamado al momento de cambiar el valor del selector, y al finalizar el procesamiento de
	 * archivos. 
	 * Modifica la cantidad de pel�culas a mostrar en la JTable de acuerdo al valor del selector.
	 */
	public void mostrarDatos () {
		String cant = (String) selector.getSelectedItem();
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        model.setRowCount(0);
        if (procesador.getLista().size()!=0) {		                    
        if (cant != "TODOS") {
            int num = Integer.parseInt(cant);
            for (int i=0; i<num; i++) {
                model.insertRow(model.getRowCount(),new Object[] {procesador.getLista().get(i).getNombre(),procesador.getLista().get(i).getCantUsuarios() ,procesador.getLista().get(i).getVotos()});
             }

        }
        else {
            for (int i=0; i<procesador.getLista().size(); i++) {
                model.insertRow(model.getRowCount(),new Object[] {procesador.getLista().get(i).getNombre(),procesador.getLista().get(i).getCantUsuarios() ,procesador.getLista().get(i).getVotos()});
                }
        }
        }
        
	}
	/**
	 * Este m�todo es llamada �nicamente cuando se terminan de procesar los archivos. Muestra en los JTextField
	 * la cantidad de pel�culas, votos y usuarios totales, y actualiza el histograma para efectivamente mostrar
	 * todos los datos.
	 * 
	 */
	public void mostrarDatosGenerales() {

        String var = procesador.getCantPeliculas()+"";
        cantFilms.setText(var); 
        var=procesador.getCantVotos()+"";
        cantVotes.setText(var);
        var=procesador.getCantUsuarios()+"";
        cantUsers.setText(var);
        //Elimina el histograma vac�o.
        contenedor.remove(2);
        Histograma histograma2 = new Histograma(procesador.getArrayVotos());
        //A�ade el histograma actualizado.
        contenedor.add(histograma2);
        contenedor.validate();
        contenedor.repaint();
	}

}