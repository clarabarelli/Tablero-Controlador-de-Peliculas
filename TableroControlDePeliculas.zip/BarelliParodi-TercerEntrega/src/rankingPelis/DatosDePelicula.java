package rankingPelis;
/**
 * Esta clase modela todos los datos necesarios para abstraer una pel�cula. 
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class DatosDePelicula {
	/**
	 * Esta clase guarda el ID de la pel�cula, su nombre, la cantidad de usuarios que votaron por esta pel�cula
	 * y la suma total de dichos votos.
	 * 
	 */
	private int ID;
	private String nombre;
	private double votos;
	private int cantUsuarios;
	
	public DatosDePelicula(int ID, String nombre) {
		this.ID=ID;
		this.nombre=nombre;
		this.votos=0;
		this.cantUsuarios=0;
	}
	/**
	 * Actualiza la cantidad de votos y de usuarios que votaron por la pel�cula.
	 * Por ejemplo, si el primer voto fue 4 y el segundo fue 5, el valor de votos ser� 9.
	 * @param votos
	 */
	public void sumarVotos(double votos) {
		this.votos=this.votos+votos;
		cantUsuarios++;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getVotos() {
		return votos;
	}

	public void setVotos(double votos) {
		this.votos = votos;
	}

	public int getCantUsuarios() {
		return cantUsuarios;
	}

	public void setCantUsuarios(int cantUsuarios) {
		this.cantUsuarios = cantUsuarios;
	}
	//@Override
	public String toString() {
		return nombre + " " + cantUsuarios +" "+ votos;
	}

	
}
