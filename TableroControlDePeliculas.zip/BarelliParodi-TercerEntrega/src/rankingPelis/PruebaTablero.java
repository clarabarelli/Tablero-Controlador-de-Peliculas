package rankingPelis;
/**
 * Contiene el m�todo main, que es que lo primero que se ejecuta al abrir la aplicaci�n.
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class PruebaTablero {
	public static void main(String[] args) {
		TableroDeControlDePeliculas miTablero = new TableroDeControlDePeliculas();
	}
}
