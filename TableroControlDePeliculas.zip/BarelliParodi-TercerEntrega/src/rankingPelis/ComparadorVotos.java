package rankingPelis;
import java.util.Comparator;
/**
 * Esta clase implementa la interfaz Comparator y define c�mo se van a comparar los datos de las pel�culas.
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class ComparadorVotos implements Comparator<DatosDePelicula> {
/**
 * El m�todo compare sirve para ordenar la lista que contiene los datos de las pel�culas en forma
 * descendente de acuerdo a la cantidad de votos.
 * @param recibe 2 DatosDePelicula para comparar seg�n sus votos.
 * @return 0 en caso de ser igual, un numero mayor a 0 si p1 es menor a p2 y un numero menor a 0 si p1 es mayor que p2.
 * 
 */
    public int compare(DatosDePelicula p1, DatosDePelicula p2) {
        Double votosP1 = p1.getVotos();
        return votosP1.compareTo(p2.getVotos()) * -1;
    }
}