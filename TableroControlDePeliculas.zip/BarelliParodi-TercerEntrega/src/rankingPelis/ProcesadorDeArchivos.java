package rankingPelis;
import java.io.*;
import java.util.*;
import javax.swing.*;
/**
 * Esta clase se encarga del procesamiento de los archivos (movies.csv y rantings.csv) y almacena todos los datos
 * relevantes que se van a mostrar en el tablero.
 * Extiende de la clase Thread, lo que permite que el procesamiento de archivos se realice de forma concurrentemente
 * con la interfaz gr�fica.
 * 
 * @author Clara Barelli y Tadeo Parodi.
 *
 */
public class ProcesadorDeArchivos extends Thread{
	/**
	 * La variable mapa se utiliza para hacer eficiente el acceso a los elementos, por ID de pel�cula.
	 * La variable lista se utiliza para almacenar de forma descendente los datos de las pel�culas por cantidad
	 * de votos.
	 * La variable cantUsers es una lista para evitar repeticiones en caso de que un usuario haya hecho m�s de un
	 * voto.
	 */
	private Map<Integer, DatosDePelicula> mapa = new HashMap<Integer, DatosDePelicula>();
	private List<DatosDePelicula> lista = new ArrayList<DatosDePelicula>();
	private LinkedList<String> cantUsers = new LinkedList<String>();
	private int cantPeliculas;
	private int cantVotos;
	private int[] arrayVotos = new int[5];
	private boolean seCargo=false;
	private JProgressBar barra;
	private TableroDeControlDePeliculas tablero;
	
	/**
	 * 
	 * @param barra, recibe una referencia de la barra de progreso para poder incrementarla de acuerdo al procesamiento
	 * de los archivos.
	 * @param t, recibe una referencia del tablero para poder enviarle un mensaje cuando termine de procesar ambos archivos.
	 */
	public ProcesadorDeArchivos(JProgressBar barra, TableroDeControlDePeliculas t) {
		super("procesador de archivos");
		this.barra=barra;
		tablero=t;
	}
	
	public void run() {
		try {
			seCargo=true;
			this.LeeDatosPeliculas();
			this.LeeDatosRankings();
			
			barra.setValue(120000);
			tablero.mostrarDatos();
			tablero.mostrarDatosGenerales();
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	/**
	 * Este m�todo procesa el archivo movies.csv por lineas, generando un objeto de tipo DatosDePelicula por
	 * cada pel�cula le�da y guard�ndolo en el HashMap. A su vez, incrementa la barra de progreso.
	 * @throws IOException
	 */
	public void LeeDatosPeliculas() throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("movies.csv")))) {
            String strLine;
            strLine = br.readLine();
            //La primer linea no es necesaria;
            strLine = br.readLine();
            while (strLine!= null) {
            	String[] info = strLine.split(",");
            	if (info[1].charAt(0) == '"') {
            		String[] arregloNombre = strLine.split("\"");
            		String nombre=arregloNombre[1];
            		info[1]=nombre;
            	}
            	DatosDePelicula datos = new DatosDePelicula( Integer.parseInt(info[0]), info[1]);
            	mapa.put(datos.getID(), datos);
            	barra.setValue(barra.getValue() +1);
            	strLine = br.readLine();
            }

            //Termina la carga de datos en el HashMap. Todas las pel�culas tienen votos 0 y cantUsuarios 0.
        }
}
	/**
	 * Este m�todo procesa el archivo ratings.csv, contando la cantidad de usuarios y actualizando los votos de las 
	 * pel�culas del mapa.
	 * Cuando finaliza el procesamiento del archivo, los datos son ordenados en una lista de forma descendiente seg�n
	 * la cantidad de votos. Luego, elimina los elementos del mapa para no ocupar tanta memoria innecesariamente.
	 * @throws IOException
	 */
	public void LeeDatosRankings() throws IOException {	
		cantVotos=0;
		inicializarArray();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("ratings.csv"))))  {
            String strLine;
            strLine = br.readLine();
            //La primer linea no es necesaria;
            strLine = br.readLine();
            while (strLine!= null) {
            	cantVotos++;
            	String[] info = strLine.split(",");
            	//Procesamiento de votos para histograma
            	procesarVoto(Float.parseFloat(info[2]));
            	//Conteo de usuarios
            	if(!cantUsers.contains(info[0])) {
            		cantUsers.add(info[0]);
            	}
            	mapa.get(Integer.parseInt(info[1])).sumarVotos(Double.parseDouble(info[2]));
            	barra.setValue(barra.getValue() +1);
            	strLine = br.readLine();
            }
            
            //Para poder mostrar los elementos usamos la lista.
            lista.clear();
            for (DatosDePelicula peli: mapa.values()) {
                lista.add(peli);
            }
            cantPeliculas=lista.size();
            lista.sort(new ComparadorVotos());
            mapa.clear();
        }
}
	
	public Map<Integer, DatosDePelicula> getMapa(){
	return mapa;	
	}
	
	public List<DatosDePelicula> getLista(){
		return lista;	
		}
	
	public int getCantUsuarios() {
		int cantUsuarios = cantUsers.size();
		cantUsers.clear();
		return cantUsuarios;
	}
	public int getCantPeliculas() {
		return cantPeliculas;
	}
	public int getCantVotos() {
		return cantVotos;
	}
	public void inicializarArray() {
		for(int i=0; i<5; i++) {
			arrayVotos[i]=0;
		}
	}
	/**
	 * Redondea el valor del voto recibido e incrementa el valor en la posici�n del arreglo que corresponda.
	 * @param voto
	 */
	public void procesarVoto(float voto) {
		if(voto <= 1.5 && voto >= 1) arrayVotos[0]++;
		else {	if (voto > 1.5 && voto <= 2.5) arrayVotos[1]++;
				else {	if (voto>2.5 && voto <= 3.5) arrayVotos[2]++;
						else { if(voto>3.5 && voto <=4.5) arrayVotos[3]++;
						else if (voto > 4.5 && voto <= 5) arrayVotos[4]++;
						}
				}
			}
		
	}
	public int[] getArrayVotos() {
		return arrayVotos;
	}
	
	public boolean getSeCargo() {
		return seCargo;
	}
	
}

